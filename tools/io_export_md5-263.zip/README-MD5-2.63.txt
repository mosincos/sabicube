Blender 2.63 MD5 Export script
===============================
Script by keless, ported to 2.63 by motorsep (http://www.kot-in-action.com/).

Development topic - http://www.katsbits.com/smforum/index.php?topic=167.0

Installation
============
For extensive installation and usage instruction read the following topic - http://www.katsbits.com/smforum/index.php?topic=178.0

Needs to be loaded and activated from "User Preferences" *regardless* as to where it's located.

Script can be installed and activated via;

	File > User Preferences... > (Install Add-Ons...)

To manually place the script, find;

	scripts\addons

Typically for Windows Vista/Win7 users, scripts folder is typically located in;

	C:\Users\[profile]\AppData\Roaming\Blender Foundation\Blender\scripts\addons

Windows XP users should look in;

	C:\Documents and Settings\[profile]\Application Data\Blender Foundation\Blender\scripts\addons

Mac/Linux;

	[location may vary]

Once placed activate from "User Preferences" - if correctly installed the "Quake Model 5 (.md5)" should appear in the "Import-Export" list, find the entry and select the *Checkbox* to enable. Close.


Usage
=====
Select both the mesh object and armature to be exported, (typically Armature is selected last). From the "File" menu select "File >> Export >> Quake Model 5 (.md5)". Issues and problems should be reported at the link above.

Misc
====
For more tools visit
http://www.katsbits.com/tools/